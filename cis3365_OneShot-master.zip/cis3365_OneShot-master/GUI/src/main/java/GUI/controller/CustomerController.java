package GUI.controller;

import GUI.Class.customer;
import GUI.DBconnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomerController implements Initializable {

    private StackPane mainContainer;

    @FXML
    public TableView<customer> table_customer;

    @FXML
    private TableColumn<?, ?> custNumber;
    @FXML
    private TableColumn<?,?> custName;
    @FXML
    private TableColumn<?,?> custName1;
    @FXML
    private TableColumn<?,?> custPhone;
    @FXML
    private TableColumn<?,?> custEmail;

    @FXML
    private TextField txt_LastName;

    @FXML
    private TextField txt_firstName;

    @FXML
    private TextField txt_phone;

    @FXML
    private TextField txt_email;

    @FXML
    private CheckBox chk_member;


    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs= null;
    private ObservableList<customer> data;


    public void initialize(URL url, ResourceBundle rb) {
        //set up tableview
        setTable();
        con=GUI.DBconnection.dConnection();
        data = FXCollections.observableArrayList();
        loadData();

    }

    public void setTable(){
        custNumber.setCellValueFactory(new PropertyValueFactory<>("num"));
        custName.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        custName1.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        custPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        custEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
    }

    public void loadData(){
        data.clear();
        try {
            pst = con.prepareStatement("SELECT Cust_Num, Cust_FirstName," +
                    "Cust_LastName, Cust_Phone, Cust_Email \n" +
                    "FROM Customer;");
            rs = pst.executeQuery();
            while(rs.next()){
                data.add(new customer(rs.getInt(1),rs.getString(2),rs.getString(3),
                        rs.getString(4),rs.getString(5)));

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        table_customer.setItems(data);

    }


    @FXML
    public void addCustomer() {

        String firstName = txt_firstName.getText();
        String lastName = txt_LastName.getText();
        String phone = txt_phone.getText();
        String email = txt_email.getText();

        String sql;
        int memType;

        if(chk_member.isSelected()){
            sql = "INSERT INTO Customer" +
                    "(Cust_FirstName, Cust_LastName, Cust_Phone, Cust_Email, Cust_MemSince, CUST_MemExpire, Mem_Num)\n" +
                    "VALUES(?,?,?,?,?,?,?);";

            Date sqlDate = Date.valueOf(LocalDate.now()); //member since
            Date sqlDate2 = Date.valueOf(LocalDate.now().plusYears(1)); // member expires.
            memType = 1; //lowest level member, automatic.


            try {
                pst = con.prepareStatement(sql);
                pst.setString(1, firstName);
                pst.setString(2,lastName);
                pst.setString(3,phone);
                pst.setString(4,email);
                pst.setDate(5,sqlDate);
                pst.setDate(6,sqlDate2);
                pst.setInt(7,memType);

                int i = pst.executeUpdate();
                if (i == 1) {
                    System.out.print("Successful");
                    loadData();
                }
            } catch (SQLException e) {
                e.printStackTrace(); }
        }

        else{
            sql = "INSERT INTO " +
                    "Customer(Cust_FirstName,, Cust_LastName, Cust_Phone, Cust_Email) Values(?,?,?,?)";

            try {
                pst = con.prepareStatement(sql);
                pst.setString(1, firstName);
                pst.setString(2,lastName);
                pst.setString(3,phone);
                pst.setString(4,email);

                int i = pst.executeUpdate();
                if (i == 1) {
                    System.out.print("Successful");
                    loadData();
                }
            } catch (SQLException e) {
                e.printStackTrace(); }
        }

    }

    @FXML
    private void deleteCustomer() {
        ObservableList<customer> selectRow;
        int toDelete = 0;

        //select items
        selectRow = table_customer.getSelectionModel().getSelectedItems();



        for (customer customer : selectRow) {
            table_customer.getItems().remove(customer);
            toDelete = customer.getNum();
        }


        try {
            pst = con.prepareStatement("DELETE FROM Customer \n" +
                    "WHERE Cust_Num = ?;");
            pst.setInt(1,toDelete);

            int i = pst.executeUpdate();
            if (i == 1) {
                System.out.print("Successful");
                loadData();
            }
        } catch (SQLException e) {
            e.printStackTrace(); }
    }




   /* public void newappoinmentbutt2(ActionEvent event) throws IOException {
        //create new scene

        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee12.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();

    }



    public void appoinment(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/Main.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }
    public void client(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/Main.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }
   */

    public void employee() throws Exception {
        switchView("employee.fxml");
    }
    public void employee1() throws Exception {
        switchView("employee1.fxml");
    }
    public void launchInventory() throws Exception {
        switchView("inventory.fxml");
    }
    public void inventory1() throws Exception {
        switchView("inventory1.fxml");
    }
    public void membership() throws Exception {
        switchView("membership.fxml");
    }
    public void other() throws Exception {
        switchView("other.fxml");
    }
    public void service() throws Exception {
        switchView("service.fxml");
    }
    public void service1() throws Exception {
        switchView("/fxml/service1.fxml");
    }

    private void switchView(String fileName) throws Exception {

        mainContainer.getChildren().clear();
        AnchorPane anchorPane = new FXMLLoader(getClass().getResource("/fxml/" + fileName)).load();
        mainContainer.getChildren().add(anchorPane);
    }


    /***********
     * These are to control menu
     */

    @FXML
    //opens up the Membership Reports Screen
    private void launchMembershipReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membershipQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
        //switchView("membershipQueries.fxml");
    }

    @FXML
    //opens up the Employee Dashboard Screen
    public void launchEmployeeDashboard(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointment Reports dashboard
    private void launchAppointmentReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointments screen
    private void launchAppointments(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Employees screen
    private void launchEmployees(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory Reports screen
    private void launchInventoryReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventoryQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    private void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }


    @FXML
    //this opens the services screen
    private void launchServices(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the service reports screen
    private void launchServiceReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/serviceQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }


}
