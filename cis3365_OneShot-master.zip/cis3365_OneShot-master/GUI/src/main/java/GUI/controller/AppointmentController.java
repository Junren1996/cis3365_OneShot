package GUI.controller;

import GUI.Class.appoinment;
import GUI.DBconnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AppointmentController implements Initializable{

    private StackPane mainContainer;
    //tableview elements
    @FXML
    public TableView<appoinment> Appoinmenttableview;
    @FXML
    private TableColumn<?,?> col1;
    @FXML
    private TableColumn<?,?> col2;
    @FXML
    private TableColumn<?,?> col3;
    @FXML
    private TableColumn<?,?> col4;
    @FXML
    private TableColumn<?,?> col5;

    @FXML
    private DatePicker datePicker;

    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs= null;
    private ObservableList<appoinment> data;

    //this is for the date selection



    public void initialize(URL url, ResourceBundle rb) {
        firstfunction();
        con=GUI.DBconnection.dConnection();
        data = FXCollections.observableArrayList();
        loaddata();
    }

    public void loaddata(){
        data.clear();

        try {
            pst = con.prepareStatement("SELECT \n" +
                    "A.Appt_Num AS 'Appoinment',\n" +
                    "CONCAT(Customer.Cust_FirstName, ' ', Customer.Cust_LastName) AS Customer,\n" +
                    "Service.Svc_Desc AS Service,\n" +
                    "/*CONCAT(E.Emp_Firstname, ' ', E.Emp_Lastname) AS Employee,\n" +
                    "Location.Loc_Street AS Location,*/\n" +
                    "CONVERT(VARCHAR, Time_Slot.Slot_Start, 100) AS 'Time',\n" +
                    "FORMAT(A.Appt_Date, 'MM/dd/yyyy') AS 'Date'\n" +
                    "\n" +
                    "\n" +
                    "FROM Customer\n" +
                    " JOIN Appointment A ON A.Cust_Num = Customer.Cust_Num\n" +
                    "LEFT JOIN Location ON Location.Loc_Num = A.Loc_Num\n" +
                    "LEFT JOIN Employee E ON E.Emp_Num = A.Emp_Num\n" +
                    "LEFT JOIN Appt_Svc S ON A.Appt_Num = S.Appt_Num\n" +
                    "LEFT JOIN Service ON S.Svc_Num = Service.Svc_Num\n" +
                    "LEFT JOIN Appt_Time T ON A.Appt_Num = T.Appt_Num\n" +
                    "LEFT JOIN Time_Slot ON T.Slot_Num = Time_Slot.Slot_Num\n" +
                    "\n" +
                    "Order by A.Appt_Date DESC, T.Slot_Num ASC;");

            rs = pst.executeQuery();

            while(rs.next()){

                data.add(new appoinment("" + rs.getString(1), rs.getString(2), "" + rs.getString(3), rs.getString(4),rs.getString(5)));
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        Appoinmenttableview.setItems(data);


    }

    public void firstfunction(){
        //set up tableview
        col1.setCellValueFactory(new PropertyValueFactory<>("appnumber"));
        col2.setCellValueFactory(new PropertyValueFactory<>("name"));
        col3.setCellValueFactory(new PropertyValueFactory<>("service"));
        col4.setCellValueFactory(new PropertyValueFactory<>("time"));
        col5.setCellValueFactory(new PropertyValueFactory<>("Date"));

    }



    public void deleteButton() {
        ObservableList<appoinment> selectRow;
        //select items
        selectRow = Appoinmenttableview.getSelectionModel().getSelectedItems();

        for (appoinment appoinment : selectRow) {
            Appoinmenttableview.getItems().remove(appoinment);
        }
    }

    public void newappoinmentbutt(ActionEvent event) throws IOException {
        //create new scene

        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/EnterClientID.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        NewPatient.getStylesheets().add("css/style.css");
        window.setScene(NewPatient);
        window.show();

    }

    public void newappoinmentbutt2(ActionEvent event) throws IOException {
        //create new scene

        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee12.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();

    }


    //this holds date to filter appointments
    private Date sqlDate;

    @FXML//this allows the date to be used for the tables
    private void submitDate(ActionEvent event) {

        sqlDate = java.sql.Date.valueOf(datePicker.getValue());
        loadFiltered();
    }

    //this will load the appointments filtered by the date
    public void loadFiltered() {
        data.clear();

        try {
            pst = con.prepareStatement("SELECT \n" +
                    "A.Appt_Num AS 'Appoinment',\n" +
                    "CONCAT(Customer.Cust_FirstName, ' ', Customer.Cust_LastName) AS Customer,\n" +
                    "Service.Svc_Desc AS Service,\n" +
                    "/*CONCAT(E.Emp_Firstname, ' ', E.Emp_Lastname) AS Employee,\n" +
                    "Location.Loc_Street AS Location,*/\n" +
                    "CONVERT(VARCHAR, Time_Slot.Slot_Start, 100) AS 'Time',\n" +
                    "FORMAT(A.Appt_Date, 'MM/dd/yyyy') AS 'Date'\n" +
                    "\n" +
                    "\n" +
                    "FROM Customer\n" +
                    " JOIN Appointment A ON A.Cust_Num = Customer.Cust_Num\n" +
                    "LEFT JOIN Location ON Location.Loc_Num = A.Loc_Num\n" +
                    "LEFT JOIN Employee E ON E.Emp_Num = A.Emp_Num\n" +
                    "LEFT JOIN Appt_Svc S ON A.Appt_Num = S.Appt_Num\n" +
                    "LEFT JOIN Service ON S.Svc_Num = Service.Svc_Num\n" +
                    "LEFT JOIN Appt_Time T ON A.Appt_Num = T.Appt_Num\n" +
                    "LEFT JOIN Time_Slot ON T.Slot_Num = Time_Slot.Slot_Num\n" +
                    "\n" +
                    "WHERE A.Appt_Date = ?" +
                    "\n" +
                    "Order by A.Appt_Date DESC, T.Slot_Num ASC;");
            pst.setDate(1, sqlDate);
            rs = pst.executeQuery();

            while (rs.next()) {

                data.add(new appoinment("" + rs.getString(1), rs.getString(2), "" + rs.getString(3), rs.getString(4), rs.getString(5)));
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        Appoinmenttableview.setItems(data);
    }


    //return value to tableview
   /* public ObservableList<customer> originalPatient() {
        String str = "2015-03-15";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate dateTime = LocalDate.parse(str, formatter);
        ObservableList<customer> person = FXCollections.observableArrayList();
        person.add(new customer("Chris", "KKK", "89586", "32482", "1881fountail"));

        return person;

    }*/

    /******
     * Idk how to use the switchViews....
     * @throws Exception
     */

    /*

    public void appoinment() throws Exception {
        switchView("appoinment.fxml");
    }
    public void client(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/Main.fxml"));
        Scene NewPatient = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        //window.getStylesheets().add(style.css);
        window.setScene(NewPatient);
        window.show();
    }
    public void employee() throws Exception {
        switchView("employee.fxml");
    }
    public void employee1() throws Exception {
        switchView("employee1.fxml");
    }
    public void inventory() throws Exception {
        switchView("invemtory.fxml");
    }
    public void inventory1() throws Exception {
        switchView("inventory1.fxml");
    }
    public void membership() throws Exception {
        switchView("membership.fxml");
    }
    public void other() throws Exception {
        switchView("other.fxml");
    }
    public void service() throws Exception {
        switchView("service.fxml");
    }
    public void service1() throws Exception {
        switchView("/fxml/service1.fxml");
    }

    private void switchView(String fileName) throws Exception {

        mainContainer.getChildren().clear();
        AnchorPane anchorPane = new FXMLLoader(getClass().getResource("/fxml/" + fileName)).load();
        mainContainer.getChildren().add(anchorPane);
    }

    */


    /****************
     * the following are to change the scene
     * @param event
     * @throws Exception
     */

    @FXML
    //opens up the Membership Reports Screen
    private void launchMembershipReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/membershipQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
        //switchView("membershipQueries.fxml");
    }

    @FXML
    //opens up the Employee Dashboard Screen
    public void launchEmployeeDashboard(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointment Reports dashboard
    private void launchAppointmentReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }


    @FXML
    //this opens the Employees screen
    private void launchEmployees(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory Reports screen
    private void launchInventoryReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventoryQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    private void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Customer screen
    private void launchCustomers(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/customer.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the services screen
    private void launchServices(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the service reports screen
    private void launchServiceReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/serviceQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

}
