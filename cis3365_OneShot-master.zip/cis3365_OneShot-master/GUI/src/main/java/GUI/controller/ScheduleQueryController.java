package GUI.controller;

import GUI.Class.employeeSechdule;
import GUI.DBconnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ScheduleQueryController implements Initializable {
    //Daily Schedule
    @FXML
    private TableView<employeeSechdule> EmpSchedTableView;
    @FXML
    private TableColumn<?, ?> DailySchedcol1;
    @FXML
    private TableColumn<?, ?> DailySchedcol2;
    @FXML
    private TableColumn<?, ?> DailySchedcol3;
    @FXML
    private TableColumn<?, ?> DailySchedcol4;
    @FXML
    private DatePicker datePicker;

    //Location Schedule
    @FXML
    private TableView<employeeSechdule> locationSchedTableview;
    @FXML
    private TableColumn<?, ?> locationSchedcol1;
    @FXML
    private TableColumn<?, ?> locationSchedcol2;
    @FXML
    private TableColumn<?, ?> locationSchedcol3;
    @FXML
    private TableColumn<?, ?> locationSchedcol4;
    @FXML
    private TextField locationSchedtf;

    //Weekly Schedule
    @FXML
    private TableView<employeeSechdule> WeeklySchedTableview;
    @FXML
    private TableColumn<?, ?> WeeklySchedcol1;
    @FXML
    private TableColumn<?, ?> WeeklySchedcol2;
    @FXML
    private TableColumn<?, ?> WeeklySchedcol3;
    @FXML
    private TableColumn<?, ?> WeeklySchedcol4;
    @FXML
    private TableColumn<?, ?> WeeklySchedcol5;
    @FXML
    private TableColumn<?, ?> WeeklySchedcol6;
    @FXML
    private TableColumn<?, ?> WeeklySchedcol7;
    @FXML
    private TableColumn<?, ?> WeeklySchedcol8;
    @FXML
    private TextField WeeklySchedtf;

    //Employee Hours
    @FXML
    private TableView<employeeSechdule> emphourTableView;
    @FXML
    private TableColumn<?, ?> emphourcol1;
    @FXML
    private TableColumn<?, ?> emphourcol2;
    @FXML
    private TableColumn<?, ?> emphourcol3;
    @FXML
    private TableColumn<?, ?> emphourcol4;
    @FXML
    private DatePicker emphourdatePicker;
    @FXML
    private TextField emphourtf;

    // most busy schedule
    @FXML
    private TableView<employeeSechdule> busyschedTableView;
    @FXML
    private TableColumn<?, ?> busyschedcol1;
    @FXML
    private TableColumn<?, ?> busyschedcol2;
    @FXML
    private TableColumn<?, ?> busyschedcol3;
    @FXML
    private TableColumn<?, ?> busyschedcol4;

    //upcomming schedule
    @FXML
    private TableView<employeeSechdule> scheduleTableView;
    @FXML
    private TableColumn<?, ?> schedulecol1;
    @FXML
    private TableColumn<?, ?> schedulecol2;
    @FXML
    private TableColumn<?, ?> schedulecol3;
    @FXML
    private TableColumn<?, ?> schedulecol4;
    @FXML
    private TableColumn<?, ?> schedulecol5;
    @FXML
    private TableColumn<?, ?> schedulecol6;


    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
    private ObservableList<employeeSechdule> DailyScheddata;
    private ObservableList<employeeSechdule> LocationScheddata;
    private ObservableList<employeeSechdule> WeeklySchedData;
    private ObservableList<employeeSechdule> emphourData;
    private ObservableList<employeeSechdule> busyschedData;
    private ObservableList<employeeSechdule> scheduleData;

    private Date sqldate;
    private int locationSchedinput;
    private int weekscheinput;
    private int emphourinput;

    public void initialize(URL url, ResourceBundle rb) {
        setDailySched();
        setLocSched();
        setWeeklySched();
        setemphour();
        setbusysched();
        setschedule();
        con = GUI.DBconnection.dConnection();
        DailyScheddata = FXCollections.observableArrayList();
        LocationScheddata = FXCollections.observableArrayList();
        WeeklySchedData = FXCollections.observableArrayList();
        emphourData = FXCollections.observableArrayList();
        busyschedData = FXCollections.observableArrayList();
        scheduleData = FXCollections.observableArrayList();
        loadbusysched();
        loadscheduleData();
    }



    private void setDailySched() {
        DailySchedcol1.setCellValueFactory(new PropertyValueFactory<>("date"));
        DailySchedcol2.setCellValueFactory(new PropertyValueFactory<>("Employee"));
        DailySchedcol3.setCellValueFactory(new PropertyValueFactory<>("Day"));
        DailySchedcol4.setCellValueFactory(new PropertyValueFactory<>("shift"));
    }

    private void setLocSched() {
        locationSchedcol1.setCellValueFactory(new PropertyValueFactory<>("date"));
        locationSchedcol2.setCellValueFactory(new PropertyValueFactory<>("Employee"));
        locationSchedcol3.setCellValueFactory(new PropertyValueFactory<>("Day"));
        locationSchedcol4.setCellValueFactory(new PropertyValueFactory<>("shift"));
    }

    private void setWeeklySched(){
        WeeklySchedcol1.setCellValueFactory(new PropertyValueFactory<>("date"));
        WeeklySchedcol2.setCellValueFactory(new PropertyValueFactory<>("Employee"));
        WeeklySchedcol3.setCellValueFactory(new PropertyValueFactory<>("Day"));
        WeeklySchedcol4.setCellValueFactory(new PropertyValueFactory<>("shift"));
        WeeklySchedcol5.setCellValueFactory(new PropertyValueFactory<>("shiftend"));
        WeeklySchedcol6.setCellValueFactory(new PropertyValueFactory<>("fbreak"));
        WeeklySchedcol7.setCellValueFactory(new PropertyValueFactory<>("sbreak"));
        WeeklySchedcol8.setCellValueFactory(new PropertyValueFactory<>("lunch"));
    }

    private void setemphour(){
        emphourcol1.setCellValueFactory(new PropertyValueFactory<>("date"));
        emphourcol2.setCellValueFactory(new PropertyValueFactory<>("Employee"));
        emphourcol3.setCellValueFactory(new PropertyValueFactory<>("Day"));
        emphourcol4.setCellValueFactory(new PropertyValueFactory<>("shift"));
    }

    private void setbusysched() {
        busyschedcol1.setCellValueFactory(new PropertyValueFactory<>("date"));
        busyschedcol2.setCellValueFactory(new PropertyValueFactory<>("Employee"));
        busyschedcol3.setCellValueFactory(new PropertyValueFactory<>("Day"));
        busyschedcol4.setCellValueFactory(new PropertyValueFactory<>("shift"));
    }

    private void setschedule() {
        schedulecol1.setCellValueFactory(new PropertyValueFactory<>("date"));
        schedulecol2.setCellValueFactory(new PropertyValueFactory<>("Employee"));
        schedulecol3.setCellValueFactory(new PropertyValueFactory<>("Day"));
        schedulecol4.setCellValueFactory(new PropertyValueFactory<>("shift"));
        schedulecol5.setCellValueFactory(new PropertyValueFactory<>("shiftend"));
        schedulecol6.setCellValueFactory(new PropertyValueFactory<>("week"));
    }

    public void clear(){
        DailyScheddata.clear();
        LocationScheddata.clear();
        WeeklySchedData.clear();
        emphourData.clear();
        busyschedData.clear();
        scheduleData.clear();
    }

    public void loadDailySchedule() {
        sqldate = java.sql.Date.valueOf(datePicker.getValue());
        try {
            pst = con.prepareStatement("SELECT \n" +
                    "CONCAT(Employee.Emp_Firstname, ' ', Employee.Emp_Lastname) AS 'Employee', \n" +
                    "Work_Shift.Shift_Num 'Shift',\n" +
                    "Workday.Day_Name  AS 'Day Working',\n" +
                    "FORMAT(Emp_Schedule.Day_Date, 'MM/dd/yyyy') Date\n" +
                    "\n" +
                    "FROM Employee\n" +
                    "JOIN Emp_Schedule ON Employee.Emp_Num = Emp_Schedule.Emp_Num\n" +
                    "JOIN Work_Shift ON Emp_Schedule.Shift_Num = Work_Shift.Shift_Num\n" +
                    "JOIN Week_Day ON Emp_Schedule.Day_Date = Week_Day.Day_Date\n" +
                    "JOIN Workday ON Week_Day.Day_Num = Workday.Day_Num\n" +
                    "\n" +
                    "WHERE Emp_Schedule.Day_Date = ?\n" +
                    "\n" +
                    "ORDER BY Employee.Emp_Lastname ASC;");
            pst.setDate(1,sqldate);
            rs = pst.executeQuery();
            while (rs.next()) {
                DailyScheddata.add(new employeeSechdule(rs.getString(1),rs.getString(2),rs.getString(3),
                        rs.getString(4)));

            }

        } catch (
                SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }

        EmpSchedTableView.setItems(DailyScheddata);
    }

    public void loadlocationSchedule(){
        locationSchedinput = Integer.parseInt(locationSchedtf.getText());
        try {
            pst = con.prepareStatement("SELECT \n" +
                    "CONCAT(Employee.Emp_Firstname, ' ', Employee.Emp_Lastname) AS Employee,\n" +
                    "Location.Loc_Street AS Location, \n" +
                    "FORMAT(Work_Week.Week_End, 'MM/dd/yyyy') AS 'Week Ending',\n" +
                    "SUM(Emp_Schedule.Emp_Hours) AS 'Total Hours'\n" +
                    "\n" +
                    "FROM Employee\n" +
                    "FULL OUTER JOIN Emp_Schedule ON Employee.Emp_Num = Emp_Schedule.Emp_Num\n" +
                    "JOIN Location ON Location.Loc_Num = Emp_Schedule.Loc_Num\n" +
                    "JOIN Week_Day ON Emp_Schedule.Day_Date = Week_Day.Day_Date\n" +
                    "JOIN Work_Week ON Week_Day.Week_Num = Work_Week.Week_Num\n" +
                    "\n" +
                    "WHERE Work_Week.Week_Num = ?\n" +
                    "\n" +
                    "GROUP BY Work_Week.Week_End, Employee.Emp_Firstname, Employee.Emp_Lastname, Location.Loc_Street;");
            pst.setInt(1,locationSchedinput);
            rs = pst.executeQuery();
            while (rs.next()) {
                LocationScheddata.add(new employeeSechdule(rs.getString(1),rs.getString(2),rs.getString(3),
                        ""+rs.getString(4)));

            }

        } catch (
                SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        locationSchedTableview.setItems(LocationScheddata);
    }

    public void loadWeeklySched(){
        weekscheinput = Integer.parseInt(WeeklySchedtf.getText());
        try {
            pst = con.prepareStatement("SELECT \n" +
                    "CONCAT(E.Emp_Firstname, ' ', E.Emp_Lastname) AS Employee,\n" +
                    "Workday.Day_Name AS Day,\n" +
                    "FORMAT(ES.Day_Date, 'MM/dd/yyyy') AS 'Date',\n" +
                    "CONVERT(VARCHAR, WS.Shift_Start, 100) AS 'Shift Start', \n" +
                    "CONVERT(VARCHAR, WS.Shift_End, 100) AS 'Shift End', \n" +
                    "CONVERT(VARCHAR, WS.Shift_Break1, 100) AS 'First Break', \n" +
                    "CONVERT(VARCHAR, WS.Shift_Break2, 100) AS 'Second Break',\n" +
                    "CONVERT(VARCHAR, WS.Shift_Lunch, 100) AS 'Lunch'\n" +
                    "\n" +
                    "FROM Work_Shift WS\n" +
                    "\n" +
                    "INNER JOIN Emp_Schedule ES ON ES.Shift_Num = WS.Shift_Num\n" +
                    "LEFT JOIN Employee E ON ES.Emp_Num = E.Emp_Num\n" +
                    "INNER JOIN Week_Day D ON ES.Day_Date = D.Day_Date\n" +
                    "JOIN Work_Week W ON D.Week_Num = W.Week_Num\n" +
                    "INNER JOIN Workday ON D.Day_Num = Workday.Day_Num\n" +
                    "\n" +
                    "WHERE W.Week_Num = ?\n" +
                    "\n" +
                    "ORDER BY ES.Day_Date, Shift_Start ASC");
            pst.setInt(1,weekscheinput);
            rs = pst.executeQuery();
            while (rs.next()) {
                WeeklySchedData.add(new employeeSechdule(rs.getString(1),rs.getString(2),rs.getString(3),
                        rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),
                rs.getString(8)));

            }

        } catch (
                SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        WeeklySchedTableview.setItems(WeeklySchedData);
    }

    public void loademphour(){
        sqldate = java.sql.Date.valueOf(emphourdatePicker.getValue());
        emphourinput = Integer.parseInt(emphourtf.getText());
        try {
            pst = con.prepareStatement("SELECT \n" +
                    "CONCAT(Employee.Emp_Firstname, ' ', Employee.Emp_Lastname) AS 'Employee',\n" +
                    "FORMAT(Work_Week.Week_End,'MM/dd/yyyy') AS 'Week Ending',\n" +
                    "COUNT(Emp_Schedule.Day_Date) AS 'Days Worked',\n" +
                    "SUM(Emp_Schedule.Emp_Hours) AS 'Total Hours'\n" +
                    "\n" +
                    "FROM Employee\n" +
                    "JOIN Emp_Schedule ON Employee.Emp_Num = Emp_Schedule.Emp_Num\n" +
                    "JOIN Week_Day ON Emp_Schedule.Day_Date = Week_Day.Day_Date\n" +
                    "JOIN Work_Week ON Week_Day.Week_Num = Work_Week.Week_Num\n" +
                    "\n" +
                    "WHERE Employee.Emp_Num = ? AND Work_Week.Week_End = ?\n" +
                    "\n" +
                    "GROUP BY Employee.Emp_Firstname, Employee.Emp_Lastname, Work_Week.Week_End, Emp_Hours\n" +
                    "\n" +
                    "ORDER BY Work_Week.Week_End DESC;");
            pst.setInt(1,emphourinput);
            pst.setDate(2,sqldate);
            rs = pst.executeQuery();
            while (rs.next()) {
                emphourData.add(new employeeSechdule(rs.getString(1),rs.getString(2),""+rs.getString(3),
                        ""+rs.getString(4)));

            }

        } catch (
                SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        emphourTableView.setItems(emphourData);
    }

    public void loadbusysched(){
        try {
            pst = con.prepareStatement("SELECT\n" +
                    "Work_Week.Week_Num AS 'Week Num', \n" +
                    "Week_Day.Day_Date AS 'Date', \n" +
                    "Workday.Day_Name AS 'Day of Week', \n" +
                    "COUNT(Emp_Schedule.Emp_Num) AS 'Employees Scheduled'\n" +
                    "\n" +
                    "FROM Work_Week\n" +
                    "JOIN Week_Day ON Work_Week.Week_Num = Week_Day.Week_Num\n" +
                    "JOIN Workday ON Week_Day.Day_Num = Workday.Day_Num\n" +
                    "JOIN Emp_Schedule ON Week_Day.Day_Date = Emp_Schedule.Day_Date\n" +
                    "\n" +
                    "\n" +
                    "GROUP BY Work_Week.Week_Num, Week_Day.Day_Date, Workday.Day_Name, Emp_Schedule.Emp_Num\n" +
                    "\n" +
                    "HAVING COUNT(Emp_Schedule.Emp_Num) > 1\n" +
                    "\n" +
                    "ORDER BY COUNT(Emp_Schedule.Emp_Num) DESC;");

            rs = pst.executeQuery();
            while (rs.next()) {
                busyschedData.add(new employeeSechdule(""+rs.getString(1),rs.getString(2),rs.getString(3),
                        ""+rs.getString(4)));

            }

        } catch (
                SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        busyschedTableView.setItems(busyschedData);
    }

    public void loadscheduleData(){
        try {
            pst = con.prepareStatement("SELECT Employee.Emp_Lastname AS 'Last Name', \n" +
                    "Employee.Emp_Firstname AS 'First Name',  \n" +
                    "Emp_Schedule.Day_Date AS 'Day Worked', \n" +
                    "Emp_Schedule.Shift_Num AS 'Shift Worked',   \n" +
                    "Emp_Schedule.Emp_Hours 'Shift Hours', \n" +
                    "Work_Week.Week_End AS 'Week Ending' \n" +
                    " \n" +
                    "FROM Employee \n" +
                    "JOIN Emp_Schedule ON Employee.Emp_Num = Emp_Schedule.Emp_Num \n" +
                    "JOIN Week_Day ON Emp_Schedule.Day_Date = Week_Day.Day_Date \n" +
                    "JOIN Work_Week ON Week_Day.Week_Num = Work_Week.Week_Num \n" +
                    "WHERE Work_Week.Week_Num BETWEEN 1 AND 5 \n" +
                    " \n" +
                    "ORDER BY Emp_Schedule.Day_Date ASC; ");

            rs = pst.executeQuery();
            while (rs.next()) {
                scheduleData.add(new employeeSechdule(rs.getString(1),rs.getString(2),rs.getString(3),
                        ""+rs.getString(4),""+rs.getString(5),rs.getString(6)));

            }

        } catch (
                SQLException ex) {
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        scheduleTableView.setItems(scheduleData);
    }




    @FXML
    //opens up the Employee Dashboard Screen
    public void launchEmployeeDashboard(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employeeReport.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointment Reports dashboard
    private void launchAppointmentReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appointmentQuery.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Appointments screen
    private void launchAppointments(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/appoinment.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Employees screen
    private void launchEmployees(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/employee1.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory Reports screen
    private void launchInventoryReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventoryQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Inventory screen
    private void launchInventory(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/inventory.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the Customer screen
    private void launchCustomers(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/customer.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the services screen
    private void launchServices(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/service.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }

    @FXML
    //this opens the service reports screen
    private void launchServiceReports(ActionEvent event) throws Exception {
        Parent NewScene = FXMLLoader.load(getClass().getResource("/fxml/serviceQueries.fxml"));
        Scene scene = new Scene(NewScene);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene.getStylesheets().add("/css/style.css");
        window.setScene(scene);
        window.show();
    }
}



