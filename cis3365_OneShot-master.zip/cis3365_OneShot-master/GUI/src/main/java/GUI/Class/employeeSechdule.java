package GUI.Class;

public class employeeSechdule {

    private String date,Employee, Day, shift;
    private String shiftend, fbreak, sbreak, lunch;
    private String week;

    public employeeSechdule(String d, String e, String day, String s){
        this.date =d;
        this.Employee =e;
        this.Day = day;
        this.shift =s;
    }
    public employeeSechdule(String d, String e, String day, String s, String se, String fb, String sb, String l){
        this.date =d;
        this.Employee =e;
        this.Day = day;
        this.shift =s;
        this.shiftend = se;
        this.fbreak = fb;
        this.sbreak = sb;
        this.lunch = l;
    }

    public employeeSechdule(String d, String e, String day, String s,String se, String w){
        this.date =d;
        this.Employee =e;
        this.Day = day;
        this.shift =s;
        this.shiftend =se;
        this.week = w;
    }



    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


    public String getEmployee() {
        return Employee;
    }

    public void setEmployee(String employee) {
        Employee = employee;
    }

    public String getDay() {
        return Day;
    }

    public void setDay(String day) {
        Day = day;
    }


    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public String getShiftend() {
        return shiftend;
    }

    public void setShiftend(String shiftend) {
        this.shiftend = shiftend;
    }

    public String getFbreak() {
        return fbreak;
    }

    public void setFbreak(String fbreak) {
        this.fbreak = fbreak;
    }

    public String getSbreak() {
        return sbreak;
    }

    public void setSbreak(String sbreak) {
        this.sbreak = sbreak;
    }

    public String getLunch() {
        return lunch;
    }

    public void setLunch(String lunch) {
        this.lunch = lunch;
    }

    public String getWeek() {
        return week;
    }

    public void setWeek(String week) {
        this.week = week;
    }
}
