package GUI.Class;



public class employee {
    private int id;
    private String name;
    private String SSN;
    private String Phone;
    private String address;
    private String role;
    private String date;



    public employee() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }




    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getSSN() {
        return SSN;
    }

    public void setSSN(String SSN) {
        this.SSN = SSN;
    }




    public String toString(int h) {
        return " " +h;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }



    public String getDate() {
        return date;
    }

    public void setDate( String date) {
        this.date = date;
    }


    //these two are for the appointment booking
    public employee(String name) {
        this.name = name;
    }

    public String toString(){
        return name;
    }



    public employee(int id, String name, String phone, String address, String role, String SSN, String h) {
        this.id = id;
        this.name = name;
        this.Phone = phone;
        this.address = address;
        this.role = role;
        this.SSN = SSN;
        this.date = h;

    }



    public String getName() {
        return name;
    }

    public void setName(String lastname) {
        this.name = lastname;
    }


    /*
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstname) {
        this.firstName = firstname;
    }
    */
}
