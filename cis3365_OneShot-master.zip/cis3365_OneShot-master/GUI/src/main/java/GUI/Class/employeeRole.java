package GUI.Class;

public class employeeRole {
    private int rolenumber;
    private String des;

    public int getRolenumber() {
        return rolenumber;
    }

    public void setRolenumber(int rolenumber) {
        this.rolenumber = rolenumber;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
