package GUI.Class;

public class workshift {
    private int shiftnumber;
    private String starttime;
    private String endtime;


    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public int getShiftnumber() {
        return shiftnumber;
    }

    public void setShiftnumber(int shiftnumber) {
        this.shiftnumber = shiftnumber;
    }
}
