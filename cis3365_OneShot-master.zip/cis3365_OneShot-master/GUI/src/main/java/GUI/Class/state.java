package GUI.Class;

public class state {
    private String countryabbreviation;
    private String stateabbreviation;
    private String statename;

    public String getStatename() {
        return statename;
    }

    public void setStatename(String statename) {
        this.statename = statename;
    }

    public String getStateabbreviation() {
        return stateabbreviation;
    }

    public void setStateabbreviation(String stateabbreviation) {
        this.stateabbreviation = stateabbreviation;
    }

    public String getCountryabbreviation() {
        return countryabbreviation;
    }

    public void setCountryabbreviation(String countryabbreviation) {
        this.countryabbreviation = countryabbreviation;
    }
}
