package GUI.Class;

public class PopService {

    private String service;
    private String requests;
    private String lastRequested;

    public PopService(String service, String requests, String last) {
        this.service = service;
        this.requests = requests;
        this.lastRequested = last;
    }


    public String getService(){
        return service;
    }

    public void setService(String service){
        this.service = service;
    }

    public String getRequests(){
        return requests;
    }

    public void setRequests(String requests){
        this.requests = requests;
    }

    public String getLastRequested(){
        return lastRequested;
    }

    public void setLastRequested(String last) {
        this.lastRequested = last;
    }

    @Override
    public String toString(){
        return "Service{" +
                ", Service ='" + service + '\'' +
                ", Requests ='" + requests + '\'' +
                ", Last Requested ='" + lastRequested + '\'' +
                '}';
    }
}
