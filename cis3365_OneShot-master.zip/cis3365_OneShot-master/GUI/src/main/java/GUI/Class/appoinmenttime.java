package GUI.Class;

public class appoinmenttime {

    private int timeslot;
    private int appoinmentnumber;


    public int getTimeslot() {
        return timeslot;
    }

    public void setTimeslot(int timeslot) {
        this.timeslot = timeslot;
    }

    public int getAppoinmentnumber() {
        return appoinmentnumber;
    }

    public void setAppoinmentnumber(int appoinmentnumber) {
        this.appoinmentnumber = appoinmentnumber;
    }
}
