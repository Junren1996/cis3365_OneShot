package GUI.Class;

public class serviceproduct {

    private int servicenumber;
    private int productnumber;

    public int getServicenumber() {
        return servicenumber;
    }

    public void setServicenumber(int servicenumber) {
        this.servicenumber = servicenumber;
    }

    public int getProductnumber() {
        return productnumber;
    }

    public void setProductnumber(int productnumber) {
        this.productnumber = productnumber;
    }
}
