package GUI.Class;

public class supplier {

    private int suppliernumber;
    private String suppliername;
    private String contact;
    private String email;
    private String phone;


    public int getSuppliernumber() {
        return suppliernumber;
    }

    public void setSuppliernumber(int suppliernumber) {
        this.suppliernumber = suppliernumber;
    }

    public String getSuppliername() {
        return suppliername;
    }

    public void setSuppliername(String suppliername) {
        this.suppliername = suppliername;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
