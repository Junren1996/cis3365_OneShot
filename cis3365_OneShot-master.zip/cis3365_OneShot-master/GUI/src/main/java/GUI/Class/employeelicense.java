package GUI.Class;

public class employeelicense {
        private int employeenumber;
        private int licensenumber;
        private String date;
        private String expire;


    public int getEmployeenumber() {
        return employeenumber;
    }

    public void setEmployeenumber(int employeenumber) {
        this.employeenumber = employeenumber;
    }

    public int getLicensenumber() {
        return licensenumber;
    }

    public void setLicensenumber(int licensenumber) {
        this.licensenumber = licensenumber;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getExpire() {
        return expire;
    }

    public void setExpire(String expire) {
        this.expire = expire;
    }
}
